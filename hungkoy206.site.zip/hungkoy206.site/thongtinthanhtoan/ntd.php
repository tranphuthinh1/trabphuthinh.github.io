<?
$ntdavt = 'https://i.imgur.com/HT7chQZ.gif'; // avatar của hình
/* ------------------------------------- */
$ntdbanner = 'https://i.imgur.com/XafrUBY.png'; // banner của hình
/* ------------------------------------- */
$ntdicon = 'https://i.imgur.com/VTHXeSL.jpg'; // thay shortcuticon và icon
/* ------------------------------------- */
$ten = 'LÊ GIA HƯNG'; // ghi full tên bằng in hoa
/* ------------------------------------- */
$tieusu = 'Hưng Kòy'; // tên tiểu sử
/* ------------------------------------- */
$tt = 'Ngày Sinh : 10/10/2006 <br>Quê Quán : Quảng Xương , Thanh Hóa <br>SDT : 0363620067 <br>Trạng Thái : Độc Thân <br>Hiện tại mình vừa học vừa làm cũng như phát triển bản thân để ngày một hoàn thiện hơn . Đối với mình mỗi ngày chỉ cần cố gắng hơn 1 chút thì tương lai chắc chắn sẽ tốt hơn'; //muốn xuống dòng thì bên <br>
/* ------------------------------------- */
$tkmbbank ='4510102006'; //nhập tk mbbank
$tenmbbank ='LÊ GIA HƯNG'; //tên mbbank
/* ------------------------------------- */
$tkmomo ='0981377408'; //nhập tk momo
$tenmomo = 'LÊ GIA HƯNG'; // tên momo
/* ------------------------------------- */
$idfb ='koy206'; // nhập id fb vào
/* ------------------------------------- */
$tencopyright ='Hưng Kòy'; //tên ở dòng coppyright
?>